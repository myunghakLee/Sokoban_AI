#include "Move.h"



bool Move::move(int y, int x) {
	int MyAround = Map[MyPositionY + y][MyPositionX + x];					//�� �����¿� �� �ϳ�
	int MyAroundAround = Map[MyPositionY + (2 * y)][MyPositionX + (2 * x)]; //�� �����¿� �� 2ĭ �� �� �� �ϳ�
	if (IsWall(MyAround)) {
		return false;
	}
	else if (IsBox(MyAround) || IsBoxInDestination(MyAround)) {
		if (IsDestination(MyAroundAround) || IsEmpty(MyAroundAround)) {
			Map[MyPositionY + (2 * y)][MyPositionX + (2 * x)] += _BOX;
			Map[MyPositionY + y][MyPositionX + x] += (_ME - _BOX);
			Map[MyPositionY][MyPositionX] -= _ME;
			return true;
		}
		else {
			return false;
		}
	}
	else if (IsEmpty(MyAround)) {
		Map[MyPositionY + y][MyPositionX + x] += _ME;
		Map[MyPositionY][MyPositionX] -= _ME;
		return true;
	}
	else if (IsDestination(MyAround)) {
		Map[MyPositionY + y][MyPositionX + x] += _ME;
		Map[MyPositionY][MyPositionX] -= _ME;
		return true;
	}

	return false;
}
void Move::moveLeft() {
	if (move(0, -1)) {
		MyPositionX--;
		move_count++;
	}
}
void Move::moveRight() {
	if (move(0, 1)) {
		MyPositionX++;
		move_count++;
	}
}
void Move::moveUp() {
	if (move(-1, 0)) {
		MyPositionY--;
		move_count++;
	}
}
void Move::moveDown() {
	if (move(1, 0)) {
		MyPositionY++;
		move_count++;
	}
}
bool Move::IsWall(int num) {
	if (num == _WALL) { return true; }
	return false;
}
bool Move::IsBox(int num) {
	if (num == _BOX) { return true; }
	return false;
}
bool Move::IsEmpty(int num) {
	if (num == _EMPTY) { return true; }
	return false;
}
bool Move::IsDestination(int num) {
	if (num == _DESTINATION) { return true; }
	return false;
}
bool Move::IsBoxInDestination(int num) {
	if (num == _BOXinDESTINATION) { return true; }
	return false;
}
void Move::DeleteMap() {
	for (int i = 0; i < height; i++) {
		delete[]Map[i];
	}
	delete[]Map;
}
void Move::PrintMap() {
	for (int i = 0; i < height; i++) {
		for (int j = 0; j < width; j++) {
			if(Map[i][j] == _EMPTY){printw("□ ");}
			else if(Map[i][j] == _OUTSIDE){printw("□ "); }
			else if(Map[i][j] == _WALL){printw("■ ");}
			else if(Map[i][j] == _BOX){printw("● ");}
			else if(Map[i][j] == _DESTINATION){attron(COLOR_PAIR(2)); printw("☆ "); attroff(COLOR_PAIR(2));}
			else if(Map[i][j] == _BOXinDESTINATION){attron(COLOR_PAIR(2));printw("★ "); attroff(COLOR_PAIR(2));}
			else if(Map[i][j] == _ME){attron(COLOR_PAIR(3)); printw("◈ "); attroff(COLOR_PAIR(2));}
			else if(Map[i][j] == _MEinDESTINATION){attron(COLOR_PAIR(3)); printw("◈ "); attroff(COLOR_PAIR(2));}
		}
		printw("\n");
	}
	printw(" X : %d\n", MyPositionX);
	printw(" Y : %d\n", MyPositionY);
	printw("move : %d\n", move_count);
}
bool Move::IsSuccess() {
	int Snum = 0;
	for (int i = 1; i < height - 1; i++) {
		for (int j = 1; j < width - 1; j++) {
			if (Map[i][j] == _BOXinDESTINATION) {
				Snum++;
			}
		}
	}
	if (Snum == NumDestinations) { return true; }
	else { return false; }
}
