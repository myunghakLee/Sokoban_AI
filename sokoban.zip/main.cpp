#include "Move.h"

using namespace std;

int map[3][110] = {{
				  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,
  				  4,  1,  1,  1,  1,  1,  1,  4,  4,  4, 
				  4,  1,  0,  0,  0,  0,  1,  4,  4,  4,
				  4,  1,100,  2,  2,  0,  1,  4,  4,  4,
				  4,  1,  0,  3,  3,  0,  1,  4,  4,  4,
				  4,  1,  0,  0,  0,  0,  1,  4,  4,  4,
				  4,  1,  1,  1,  1,  1,  1,  4,  4,  4,
				  4,  4,  4,  4,  4,  4,  4,  4,  4,  4, 
				  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,
				  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,
				  4,  4,  4,  4,  4,  4,  4,  4,  4,  4

				  },
				  {
				  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,
  				  4,  1,  1,  1,  1,  4,  4,  4,  4,  4, 
				  4,  1,  3,  0,  1,  1,  4,  4,  4,  4,
				  4,  1,  3,100,  0,  1,  4,  4,  4,  4,
				  4,  1,  3,  0,  2,  1,  4,  4,  4,  4,
				  4,  1,  1,  2,  0,  1,  1,  1,  4,  4,
				  4,  4,  1,  0,  2,  0,  0,  1,  4,  4,
				  4,  4,  1,  0,  0,  0,  0,  1,  4,  4, 
				  4,  4,  1,  0,  0,  1,  1,  1,  4,  4,
				  4,  4,  1,  1,  1,  1,  1,  1,  4,  4,
				  4,  4,  4,  4,  4,  4,  4,  4,  4,  4
				  },
				  {
				  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,
  				  4,  1,  1,  1,  1,  1,  1,  1,  1,  4, 
				  4,  1,  3,  0,  0,  0,  0,  0,  1,  4,
				  4,  1,  0,  3,  2,  2,  2,100,  1,  4,
				  4,  1,  3,  0,  0,  0,  0,  0,  1,  4,
				  4,  1,  1,  1,  1,  1,  0,  0,  1,  4,
				  4,  4,  4,  4,  4,  1,  1,  1,  1,  4,
				  4,  4,  4,  4,  4,  4,  4,  4,  4,  4, 
				  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,
				  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,
				  4,  4,  4,  4,  4,  4,  4,  4,  4,  4
				  }
				  };

void init_scr();
int frontUI();


int main() {
	
	init_scr();
	bkgd(COLOR_PAIR(1));
	printw("S O K O B A N !\n");
	printw("Press 's' to play game!\n");
	printw("Press 'q' to quit!\n");
	refresh();
	while(1){
		char start = getch();
		if(start == 's'){
			char key;
			bool success = false;
			for(int i = 0; i < 3; i++){
				Move M(map[i], 11, 10);
				while(1){
					clear();
					printw("STAGE %d\n", i+1);
					M.PrintMap();
					printw("press key to move player\n");
					printw("w - UP  s - DOWN  a - LEFT  d - RIGHT\n");
					refresh();
					char key = getch();
					if (key == 'w') {
						M.moveUp();
					}
					else if (key == 's') {
						M.moveDown();
					}
					else if (key == 'a') {
						M.moveLeft();
					}
					else if (key == 'd') {
						M.moveRight();
					}
					//check game fin 
					if (M.IsSuccess()) {
						clear();
						M.PrintMap();
						printw("STAGE %d SUCCESS!\n", i+1);
						printw("press any key to continue!\n");
						refresh();
						if(i+1 == 3){
							start = 'q';
						}
						getch();
						break;
					}
				}
			}
		}
		if(start == 'q'){
			printw("BYE!\n");
			refresh();
			break;
		}
		touchwin(stdscr);
		refresh();
		endwin();
	}

}
void init_scr()
{
	setlocale(LC_ALL, "");
    initscr();
    start_color();
    init_pair(1, COLOR_WHITE, COLOR_BLACK);
	init_pair(2, COLOR_YELLOW, COLOR_BLACK);
	init_pair(3, COLOR_RED, COLOR_BLACK);
    curs_set(2);
    noecho();
    keypad(stdscr, TRUE);
}